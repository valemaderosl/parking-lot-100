// Example data for parking lots
const parkingLots = [
    { name: 'Lot A', availableSpots: 10 },
    { name: 'Lot B', availableSpots: 0 },
    { name: 'Lot C', availableSpots: 5 },
    { name: 'Lot D', availableSpots: 2 },
];

// Function to render parking lots
function renderParkingLots() {
    const parkingLotsDiv = document.getElementById('parking-lots');

    // Clear the current content
    parkingLotsDiv.innerHTML = '';

    // Loop through the parking lots and create elements for each one
    parkingLots.forEach(lot => {
        const lotDiv = document.createElement('div');
        lotDiv.classList.add('parking-lot');

        const lotName = document.createElement('h3');
        lotName.textContent = lot.name;

        const lotAvailability = document.createElement('p');
        lotAvailability.textContent = lot.availableSpots > 0 
            ? `${lot.availableSpots} spots available` 
            : 'Full';
        lotAvailability.classList.add(lot.availableSpots > 0 ? 'available' : 'full');

        // Append the elements to the div
        lotDiv.appendChild(lotName);
        lotDiv.appendChild(lotAvailability);

        // Append the lot div to the main parking lots container
        parkingLotsDiv.appendChild(lotDiv);
    });
}

// Call the function to render parking lots on page load
renderParkingLots();
